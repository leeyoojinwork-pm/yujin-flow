# YUJIN FLOW | Claude Code 선택 실습

1. 이 ZIP을 빈 실습 폴더에 풀고 Claude Code로 해당 폴더를 연다.
2. CLAUDE.md, .claude/agents/review-feedback.md와 Skill 파일을 확인한다.
3. 아래 요청을 보낸다.

data/feedback-a.csv를 feedback-to-actions Skill로 분석하고 output/classification.csv와 output/improvement-report.md를 만들어줘. scripts/verify_outputs.py로 분류 파일을 검증한 뒤 review-feedback Subagent에게 입력 파일, 출력 파일, 기준 파일 경로와 검수 작업을 전달해줘. 검수 실패 시 해당 항목만 최대 2회 수정하고 다시 검수해줘. 두 번 수정해도 실패하면 중단하고 질문해줘. 실제 위임과 실행 결과를 보여주고 강사 승인 전에는 외부에 보내지 마.

## 확인

실제 실행 활동에 review-feedback 위임이 나타났는지 확인한다. 새 agents 폴더를 세션 도중 처음 만들었고 인식되지 않으면 Claude Code를 다시 연다. 외부 API나 데이터베이스 연결은 포함하지 않는다.

구조 검증만 직접 실행하려면:

python3 scripts/verify_outputs.py data/feedback-a.csv reference-results/expected-classification-a.csv

이 검증은 ID·카테고리·원문 인용을 확인하며 의미 분류와 개선안의 적절성을 보장하지는 않는다.
