"""Validate CS inquiry classification against its source CSV using Python stdlib."""
import csv
import sys
from collections import Counter
from pathlib import Path

def read_rows(path, required):
    with Path(path).open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not required.issubset(reader.fieldnames or []):
            raise ValueError(f"Missing columns in {path}: {required}")
        return list(reader)

def verify(source_path, result_path):
    source = read_rows(source_path, {"id", "score", "comment"})
    result = read_rows(result_path, {"id", "category", "evidence"})
    ids = [row["id"] for row in source]
    if len(ids) != len(set(ids)) or any(not key for key in ids):
        raise ValueError("Source IDs must be nonempty and unique")
    if Counter(ids) != Counter(row["id"] for row in result):
        raise ValueError("Missing, extra, or duplicate output IDs")
    lookup = {row["id"]: row["comment"] for row in source}
    categories = {"배송", "반품·환불", "결제", "계정", "미응답", "기타"}
    for row in result:
        raw = lookup[row["id"]]
        evidence = row["evidence"]
        if row["category"] not in categories:
            raise ValueError("Unknown category: " + row["category"])
        if not raw.strip():
            if row["category"] != "미응답" or evidence.strip():
                raise ValueError("Blank responses must stay in the missing-response category")
        elif not evidence.strip() or evidence not in raw:
            raise ValueError(f"Evidence does not match source ID {row.get('id')}")
    print(f"PASS: {len(source)} source rows, complete IDs, valid categories, source-grounded evidence")
    print("Meaning of categories and report claims still require human or independent review.")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Usage: python3 scripts/verify_outputs.py data/inquiries-a.csv output/classification.csv")
    try:
        verify(sys.argv[1], sys.argv[2])
    except (ValueError, OSError, csv.Error) as exc:
        raise SystemExit("FAIL: " + str(exc))
